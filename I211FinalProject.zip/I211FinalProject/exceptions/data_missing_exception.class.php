<?php

class DataMissingException extends \Exception
{

}