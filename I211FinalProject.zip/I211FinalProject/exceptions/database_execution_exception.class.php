<?php

class DatabaseExecutionException extends \Exception
{

}